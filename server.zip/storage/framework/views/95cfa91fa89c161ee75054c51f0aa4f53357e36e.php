<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(asset("/vendor/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css")); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("/vendor/adminlte/plugins/daterangepicker/daterangepicker.css")); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="content-header">
                <h1>
                    Create New Contest
                    <small></small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
                    <li class="active">Here</li>
                </ol>
    </section>

            <!-- Main content -->
    <section class="content">

         <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        
        <!-- /.box-header -->
        <div class="box-body">

        <form method="POST" action=<?php echo e(url('/create_contest')); ?>>
        <?php echo e(csrf_field()); ?>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Conntest Title</label>
                <input name="title" type="text" class="form-control pull-right" style="width: 100%;" placeholder="Contest Name to be Shown">
                </input>
              </div>
            </div>
            <!-- /.col -->

            <div class="col-md-6">
              <!-- Date and time range -->
              <div class="form-group">
                <label>Conntest Duration:</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-clock-o"></i>
                  </div>
                  <input name="start_end_time" type="text" class="form-control pull-right" id="reservationtime">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
            </div>
            <!-- /.col (right) -->

            <div class="col-md-12">
              <div class="form-group">
                <label>Contest Details:</label>
             
                  <textarea name="description" class="textarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            
              </div>
              <!-- /.form group -->
            </div>
            <!-- /.col-->

          </div>
          <!-- /.row -->
            <div class="box-footer">
                <button type="submit" class="btn bg-olive btn-flat">Create</button>
                <button type="reset" class="btn bg-orange btn-flat">Cancel</button>
            </div>
        </form>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->


    </section><!-- /.content -->


<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_js'); ?>

    <script src="<?php echo e(asset ("/vendor/adminlte/plugins/daterangepicker/moment.min.js")); ?>"></script>
    <script src="<?php echo e(asset ("/vendor/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js")); ?>"></script>
    <script src="<?php echo e(asset ("/vendor/adminlte/plugins/daterangepicker/daterangepicker.js")); ?>"></script>



    <script>
    $(function () {

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
        timePicker: true, 
        timePickerIncrement: 30, 
        locale: {
            format: 'DD/MM/YYYY H:mm'
        }
        });
    $(".textarea").wysihtml5();


  });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>