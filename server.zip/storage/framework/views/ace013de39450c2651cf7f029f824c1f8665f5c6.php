    <!-- Main content -->
    <section class="content">

      <?php $__currentLoopData = $contests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-<?php echo e($column); ?>">
          <!-- small box -->
          <?php if(($loop->iteration)%2 == 0): ?>
            <div class="small-box bg-green">
          <?php else: ?>
            <div class="small-box bg-red">
          <?php endif; ?>

            <div class="inner">
              <h3><?php echo e($contest->title); ?></h3>

              <p><?php echo e($contest->start_time); ?></p>
              <p><?php echo e($contest->end_time); ?></p>
            </div>
            <a href="<?php echo e(url('/contest/'.$contest->id)); ?>" class="small-box-footer">
              Go to Contest <i class="fa fa-arrow-circle-right"></i>
            </a>
        </div>
        <!-- ./col -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
    <!-- /.content -->