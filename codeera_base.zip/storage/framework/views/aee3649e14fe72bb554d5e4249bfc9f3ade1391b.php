<?php $__env->startSection('content'); ?>


<div class="container">
<!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-warning">
        <div class="box-header with-border bg-olive ">
          <div class="col-md-6">
            
            <h2 class="pull-left"><b><?php echo e($contest->title); ?></b></h2>
          </div>
          
          <div class="col-md-4">
            <p hidden>Starting In<button  class="btn btn-flat margin bg-orange lead"><b id="timer_one" style="font-size: 20px;"></b></button></p>
            <p hidden>Ending In<button  class="btn btn-flat margin bg-orange lead"><b id="timer_two" style="font-size: 20px;"></b></button></p>
          </div>
          <div class="col-md-2" style="margin-top: 25px">
            <a href="<?php echo e(url('/ranking/'.$contest->id)); ?>" class="btn btn-flat bg-orange">Ranking</a>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="col-md-12">
              <div class="box box-default box-solid">
                <div class="box-header with-border text-center">
                  <h3>Contest Description</h3>
                </div>
                <div class="box-body bg-white">
                  <p style="text-align: justify;"><?php echo $contest->description; ?></p>
                </div>
                <!-- /.box-body -->


          <div class="box-footer">
          <?php 
          $current = Carbon\Carbon::now('Asia/Dhaka')->toDateTimeString();
          $enrollTime = Carbon\Carbon::parse($contest->start_time)->subHours(4); 
          //var_dump(Auth::check());       
          //dd(Carbon\Carbon::now('Asia/Dhaka')->gt(Carbon\Carbon::parse($contest->start_time)));       
           ?>

          <?php if(Carbon\Carbon::parse($current)->lt($enrollTime)): ?>
            <?php if( Auth::check() && $contest->user->contains(Auth::user()) ): ?>
            <div class="col-md-4 col-md-offset-4">
              <button class="btn bg-orange btn-flat center-block"><i class="fa fa-check"></i> Already Enrolled</button>
            </div>
            <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
              <a href="<?php echo e(url("/contest/enroll/".$contest->id)); ?>" class="btn bg-orange btn-flat center-block">Enroll</a>
            </div>
            <?php endif; ?>
          <?php endif; ?>
          </div>
              </div>
            </div>
            <!-- /.col-->
          <?php if(Auth::check() && Carbon\Carbon::parse($current)->gt(Carbon\Carbon::parse($contest->start_time))): ?>
            <div class="col-md-12">
              <div class="box box-default box-solid">
                <div class="box-header with-border text-center">
                  <h3>Problem List</h3>
                </div>
                <div class="box-body">
                  <table id="example2" class="table table-bordered table-hover text-center">
                    <thead>
                    <tr>
                      <th style="width: 10%">Problem No</th>
                      <th style="width: 90%">Problem Link</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contest->problem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td> (<?php echo e($key+1); ?>) </td>
                      <td>  <a href="<?php echo e(url('problem/'.$problem->id)); ?>"><?php echo e($problem->title); ?></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.box-body -->
              </div>
            </div>
          <?php endif; ?>
            <!-- /.col-->
        <!-- /.box-body -->
      </div>

      <!-- /.box -->
      </div>

    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('custom_js'); ?>
            <script src="<?php echo e(asset ("js/jquery.countdown.min.js")); ?>"></script>

            <script type="text/javascript">
                var $timer1 = $('#timer_one');
                var $timer2 = $('#timer_two');
                
                var $start = '<?php echo e($contest->start_time); ?>';
                var $end = '<?php echo e($contest->end_time); ?>';
                $timer1.parents("p").show();
                counting($start, $timer1);
                  
                $timer1.on('finish.countdown', function(event){
                          $(this).parents("p").html('');
                          $timer2.parents("p").show();
                          counting($end, $timer2);
                          
                });
                $timer2.on('finish.countdown', function(event){
                          $(this).parents("p").html('<button  class="btn btn-flat margin bg-orange lead"><b  style="font-size: 20px;">Ended</b></button>');
                       
                          
                          
                });
                  
                function counting($time, $timer) {
                  $timer.countdown($time, function(event) {
                      $(this).html(event.strftime('%-d day(s) %H:%M:%S'));
                  });
                }
            </script>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>