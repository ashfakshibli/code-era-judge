    <!-- Main content -->
    <section class="content">
      
      <?php $__currentLoopData = $problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php 
        $now = Carbon\Carbon::now('Asia/Dhaka');
        $end = Carbon\Carbon::parse($problem->contest['end_time']);

       ?>
        <?php if( Carbon\Carbon::parse($now)->gt($end)): ?>
        <div class="col-lg-<?php echo e($column); ?>">
          <!-- small box -->
          <?php if(($loop->iteration)%2 == 0): ?>
            <div class="small-box bg-green">
          <?php else: ?>
            <div class="small-box bg-red">
          <?php endif; ?>

            <div class="inner">
              <h3>#<?php echo e($problem->id); ?></h3>

              <h4><?php echo e($problem->title); ?></h4>
              <p><?php echo e($problem->contest['title']); ?></p>
            </div>
            <a href="<?php echo e(url('/problem/'.$problem->id)); ?>" class="small-box-footer">
              Go to Problem <i class="fa fa-arrow-circle-right"></i>
            </a>
        </div>
        <!-- ./col -->
      </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
    <!-- /.content -->