<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(asset("/vendor/adminlte/plugins/datatables/dataTables.bootstrap.css")); ?>" rel="stylesheet" type="text/css" />
    

    <style>
   table { table-layout: fixed; }
   table th, table td {
        max-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
  </style>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
<div class="container">

    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-warning">
        <div class="box-header with-border">
          <div class="col-md-4">
            <h3><?php echo e($contestData->title); ?></h3>(Ranking)
          </div>
          <div class="col-md-4 pull-right">
            <button type="button" class="btn btn-flat btn-info margin">Solved problem</button>
            <button type="button" class="btn btn-flat bg-red margin">Attempted problem</button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">

            <div class="col-md-12">
              <div class="box box-warning">
                <div class="box-body">
                  <table id="example2" class="table table-bordered text-center">
                    <thead>
                    <tr class="bg-gray">
                      <th >Rank</th>
                      <th style="width: 20%">Contestant Name</th>
                      <th >Solved</th>
                      <th >Time</th>
                      <?php 
                      $letter = range('A', 'Z');
                       $count = count($contestData->problem);
                       ?>
                      <?php for($i=0; $i<$count; $i++): ?>
                      <th ><?php echo e($letter[$i]); ?></th>
                      <?php endfor; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sortedRankingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($data['contestant_name']); ?></td>
                        <td><?php echo e($data['solved']); ?></td>
                        <td><?php echo e($data['time_point']); ?></td>
                        <?php $__currentLoopData = $data['problem']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem => $problem_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($problem_data['result'] == 'AC'): ?>
                              <td class="btn-success">
                                <i class="fa fa-check"></i>
                              </td>
                          <?php elseif($problem_data['result'] == 'WA'): ?>
                              <td class="bg-red">
                                <i class="fa icon-remove-sign"></i>

                              </td>
                          <?php else: ?>
                              <td>
                              ...
                              </td>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.box-body -->
              </div>
            </div>
            <!-- /.col-->

        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

    <script src="<?php echo e(asset ("/vendor/adminlte/plugins/datatables/jquery.dataTables.min.js")); ?>"></script>
    <script src="<?php echo e(asset ("/vendor/adminlte/plugins/datatables/dataTables.bootstrap.min.js")); ?>"></script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>