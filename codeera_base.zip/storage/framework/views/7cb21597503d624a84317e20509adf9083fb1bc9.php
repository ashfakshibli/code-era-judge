<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-lg-8">
	<section class="content-header text-center">
      <h1>
        Upcoming Contests
      </h1>
    </section>

    <?php echo $__env->make('layouts.contests', ['column'=>'12'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



	</div>

    <div class="col-lg-4">
    <br>
    	<div class="box box-solid text-center">
    		<div class="box-header with-border">
    			<h3 class="box-title">Our Well Wishers</h3>
		    		<div class="box-body bg-teal">
		    			<div class="box-comment ">
			                <!-- User image -->
			                <img class="img-circle img-sm" src="<?php echo e(asset("/images/default_user.png")); ?>" alt="User Image">
			                <span class="username">
			                        Rahma Bintey Mufiz Mukta
			                        <br>
			                        Asst. Professor, CSE, CUET
			                      </span><!-- /.username -->

			                <div class="comment-text">
			                      
			                      <br>
			                  
			                </div>
			                <!-- /.comment-text -->
			             </div>
		    		</div>
    		</div>
    		
    	</div>
    	
    	<?php echo $__env->make('layouts.portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>