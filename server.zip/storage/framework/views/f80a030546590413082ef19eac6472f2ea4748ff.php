<?php if(Session::has('message')): ?>
  <br>
        <div class="container">
            <div class="alert <?php echo e(Session::get('alert-class','alert-info')); ?> alert-dismissible col-md-8">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i> <?php echo e(Session::get('alert-heading','Alert!')); ?></h4>
                    <?php echo e(Session::get('message')); ?>

            </div>
  </div>
<?php endif; ?>