        <footer class="main-footer">
            <!-- To the right -->
            <div class="pull-right hidden-xs">
                Contest Redefined
            </div>
            <!-- Default to the left -->
            <strong>Copyright © 2017 <a href="#">CodeEra</a>.</strong> All rights reserved.
        </footer>
