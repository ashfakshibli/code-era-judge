<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-lg-12">
	<section class="content-header text-center">
      <h1>
        Contests You Have Enrolled
      </h1>
    </section>

      <!-- Main content -->
    <section class="content">

      <?php $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-8 col-lg-offset-2">
          <!-- small box -->
          <?php if(($loop->iteration)%2 == 0): ?>
            <div class="small-box bg-light-blue-gradient">
          <?php else: ?>
            <div class="small-box bg-light-blue-gradient">
          <?php endif; ?>

            <div class="inner">
              <h3><?php echo e($contest->title); ?></h3>
              <h4 data-time="<?php echo e($contest->start_time); ?>" class="pull-right"><?php echo e($contest->start_time); ?></h4>


              <h5><?php echo e(Carbon\Carbon::parse($contest->start_time)->format('d-F-Y  H:i')); ?></h5>

            </div>
            <a href="<?php echo e(url('/contest/'.$contest->id)); ?>" class="small-box-footer">
              Go to Contest <i class="fa fa-arrow-circle-right"></i>
            </a>
        </div>
        <!-- ./col -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
    <!-- /.content -->

    <?php $__env->startSection('custom_js'); ?>
            <script src="<?php echo e(asset ("js/jquery.countdown.min.js")); ?>"></script>

            <script type="text/javascript">
                $('[data-time]').each(function() {
                    var $this = $(this), finalDate = $(this).data('time');
                    $this.countdown(finalDate, function(event) {
                    $this.html(event.strftime('%-D day(s) %H:%M:%S'));
                    });
                    $this.on('finish.countdown', function(event){
                        $(this).html('');
                    });

                });
            </script>

    <?php $__env->stopSection(); ?>
 
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('contestant.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>