#include <stdio.h>

int main()
{
    int m;
    scanf("%d",&m);
    printf("%d", m/2);
    return 0;
}
