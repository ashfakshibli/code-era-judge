    <!-- Main content -->
    
      <div class="row">
        <div class="col-lg-12">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>{{ $contest_title }}</h3>

              <p>{{ $contest_time }}</p>
              <p>{{ $contest_duration }}</p>
            </div>
            <a href="{{ $contest_url }}" class="small-box-footer">
              Go to Contest <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
      </div>
 

     {{--  <div class="row">
        <div class="col-lg-12">

          <div class="small-box bg-red">
            <div class="inner">
              <h3>Contest Four</h3>

              <p>Unique Visitors</p>
            </div>
            <a href="#" class="small-box-footer">
              Go to contest <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

      </div>
 --}}

      <!-- =========================================================== -->


    <!-- /.content -->