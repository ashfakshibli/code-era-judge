<?php $__env->startSection('content'); ?>


<div class="container">
<!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-warning">
        <div class="box-header with-border bg-olive text-center">
          <h2><b><?php echo e($contest->title); ?></b></h2>

        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="col-md-12">
              <div class="box box-success box-solid">
                <div class="box-header with-border text-center">
                  <h3>Contest Description</h3>
                </div>
                <div class="box-body bg-white">
                  <p style="text-align: justify;"><?php echo $contest->description; ?></p>
                </div>
                <!-- /.box-body -->


          <div class="box-footer">
          <form method="POST" action="/contest/enroll">
          <?php echo e(csrf_field()); ?>

            <input type="hidden" name="contest_id" value="<?php echo e($contest->id); ?>">
            <div class="col-md-12">
              <button type="submit" class="btn bg-orange btn-flat center-block">Enroll</button>
            </div>
            <!-- /.col-->
          </form>
          </div>
              </div>
            </div>
            <!-- /.col-->

            <div class="col-md-12">
              <div class="box box-success box-solid">
                <div class="box-header with-border text-center">
                  <h3>Problem List</h3>
                </div>
                <div class="box-body">
                  <table id="example2" class="table table-bordered table-hover text-center">
                    <thead>
                    <tr>
                      <th style="width: 10%">Problem No</th>
                      <th style="width: 90%">Problem Link</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contest->problem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td> (<?php echo e($loop->count); ?>) </td>
                      <td>  <a href="#"><?php echo e($problem->title); ?></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.box-body -->
              </div>
            </div>
            <!-- /.col-->
        <!-- /.box-body -->
      </div>

      <!-- /.box -->
      </div>

    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>