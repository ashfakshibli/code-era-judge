    <!-- Main content -->
    
      <div class="row">
        <div class="col-lg-12">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo e($contest_title); ?></h3>

              <p><?php echo e($contest_time); ?></p>
              <p><?php echo e($contest_duration); ?></p>
            </div>
            <a href="<?php echo e($contest_url); ?>" class="small-box-footer">
              Go to Contest <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
      </div>
 

     

      <!-- =========================================================== -->


    <!-- /.content -->