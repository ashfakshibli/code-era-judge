<p align="center">CodeEra</p>



## About CodeEra

CodeEra is a web contest platform

- [For Individual University, College, School Contest Platform for there own management]
- [Built with Laravel the best PHP framework] (https://laravel.com)
